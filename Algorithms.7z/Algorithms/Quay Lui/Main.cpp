#include <iostream>
using namespace std;
int *a;
int n=4;
void Try(int);
void solve (int n)
{
	a=new int[n];
	Try(0);
}

void solution()
{
	for(int i=0;i<n;i++)
	{
		cout<<a[i];
	}
	cout<<endl;

}
bool check(int v,int k)
{
	return true;
}

void Try(int k)
{
	int v;
	for(v=0;v<=1;v++)
	{
		a[k]=v;
		if(k==n-1)
		{
			solution();
		}
		else
		{
			Try(k+1);
		}
	}
}
int main()
{
	solve(4);
	system("pause");
	return 0;
}