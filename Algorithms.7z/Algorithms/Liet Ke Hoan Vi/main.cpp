#include <iostream>
using namespace std;
int *x;
bool mark[5]={0,0,0,0,0};
int n=3;
void Try(int);
void solve()
{
	x=new int[4];
	Try(1);
}
bool check(int v,int k)
{
	
	return !mark[v];
}
void solution()
{
	for(int i=1;i<=n;i++)
	{
		cout<<x[i];
	}
	cout<<endl;
}
 void Try(int k)
{
	int v;
	for(v=1;v<=n;v++)
	{
		if(check(v,k))
		{
			x[k]=v;
			mark[v]=true;
			if(k==n)
			{solution();}
			else
			{
				Try(k+1);
			}
			mark[v]==false;
		}
		
	}
}
int main()
{
	
	solve();
	
	system("pause");
	delete x;
	
	return 0;
}