#include <iostream>
using namespace std;
int *x;
int n=3,m=5,T=0;
void Try(int);
void solve()
{
	x=new int[n+1];
	Try(1);
}
bool check(int v,int k)
{
	if(k==n)
		return (T+v==m);
	return T+v<m;
}
void solution()
{
	for(int i=1;i<=n;i++)
	{
		cout<<x[i];
	}
	cout<<endl;
}
 void Try(int k)
{
	int v;
	for(int v=1;v<=m-T;v++)
	{
		if(check(v,k))
		{
			x[k]=v;
			T+=x[k];
			if(k==n)
				solution();
			else
			{
				Try(k+1);
			}
			T-=x[k];
		}
		
	}
}
int main()
{
	

	solve();
	system("pause");
	return 0;
}